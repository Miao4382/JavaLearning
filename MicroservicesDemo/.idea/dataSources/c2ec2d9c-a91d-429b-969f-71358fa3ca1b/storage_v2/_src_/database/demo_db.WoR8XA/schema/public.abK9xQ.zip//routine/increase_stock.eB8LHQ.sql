create procedure increase_stock(IN stock_limit integer, IN amount integer)
    language plpgsql
as
$$
begin
    update books
    set qty = qty + amount
    where qty < stock_limit;

    commit;
end;
$$;

alter procedure increase_stock(integer, integer) owner to postgres;

